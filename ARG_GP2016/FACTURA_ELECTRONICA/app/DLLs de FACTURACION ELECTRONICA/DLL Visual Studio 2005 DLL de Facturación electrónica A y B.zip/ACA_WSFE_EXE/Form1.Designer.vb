<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.Button5 = New System.Windows.Forms.Button
        Me.Button6 = New System.Windows.Forms.Button
        Me.Button7 = New System.Windows.Forms.Button
        Me.prodMode = New System.Windows.Forms.TextBox
        Me.scuit = New System.Windows.Forms.TextBox
        Me.sid = New System.Windows.Forms.TextBox
        Me.sUniqueId = New System.Windows.Forms.TextBox
        Me.stoken = New System.Windows.Forms.TextBox
        Me.ssign = New System.Windows.Forms.TextBox
        Me.soptype = New System.Windows.Forms.TextBox
        Me.sopnumber = New System.Windows.Forms.TextBox
        Me.server = New System.Windows.Forms.TextBox
        Me.base = New System.Windows.Forms.TextBox
        Me.usuario = New System.Windows.Forms.TextBox
        Me.password = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(44, 87)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(98, 31)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "ticketYcae"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(44, 139)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(98, 31)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "ultimoID"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(44, 189)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(98, 31)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "ultimoNro"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(182, 87)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "Enviar mail"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(182, 139)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 45)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "Obtener CAE Lote"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(182, 196)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 38)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "Consultar CAE"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(44, 22)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(98, 32)
        Me.Button7.TabIndex = 6
        Me.Button7.Text = "wsfex"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'prodMode
        '
        Me.prodMode.Location = New System.Drawing.Point(54, 258)
        Me.prodMode.Name = "prodMode"
        Me.prodMode.Size = New System.Drawing.Size(100, 20)
        Me.prodMode.TabIndex = 7
        '
        'scuit
        '
        Me.scuit.Location = New System.Drawing.Point(301, 258)
        Me.scuit.Name = "scuit"
        Me.scuit.Size = New System.Drawing.Size(100, 20)
        Me.scuit.TabIndex = 8
        '
        'sid
        '
        Me.sid.Location = New System.Drawing.Point(54, 284)
        Me.sid.Name = "sid"
        Me.sid.Size = New System.Drawing.Size(100, 20)
        Me.sid.TabIndex = 9
        '
        'sUniqueId
        '
        Me.sUniqueId.Location = New System.Drawing.Point(301, 284)
        Me.sUniqueId.Name = "sUniqueId"
        Me.sUniqueId.Size = New System.Drawing.Size(100, 20)
        Me.sUniqueId.TabIndex = 10
        '
        'stoken
        '
        Me.stoken.Location = New System.Drawing.Point(54, 310)
        Me.stoken.Name = "stoken"
        Me.stoken.Size = New System.Drawing.Size(514, 20)
        Me.stoken.TabIndex = 11
        '
        'ssign
        '
        Me.ssign.Location = New System.Drawing.Point(54, 336)
        Me.ssign.Name = "ssign"
        Me.ssign.Size = New System.Drawing.Size(514, 20)
        Me.ssign.TabIndex = 12
        '
        'soptype
        '
        Me.soptype.Location = New System.Drawing.Point(54, 362)
        Me.soptype.Name = "soptype"
        Me.soptype.Size = New System.Drawing.Size(100, 20)
        Me.soptype.TabIndex = 13
        '
        'sopnumber
        '
        Me.sopnumber.Location = New System.Drawing.Point(301, 362)
        Me.sopnumber.Name = "sopnumber"
        Me.sopnumber.Size = New System.Drawing.Size(100, 20)
        Me.sopnumber.TabIndex = 14
        '
        'server
        '
        Me.server.Location = New System.Drawing.Point(54, 389)
        Me.server.Name = "server"
        Me.server.Size = New System.Drawing.Size(100, 20)
        Me.server.TabIndex = 15
        '
        'base
        '
        Me.base.Location = New System.Drawing.Point(301, 388)
        Me.base.Name = "base"
        Me.base.Size = New System.Drawing.Size(100, 20)
        Me.base.TabIndex = 16
        '
        'usuario
        '
        Me.usuario.Location = New System.Drawing.Point(54, 416)
        Me.usuario.Name = "usuario"
        Me.usuario.Size = New System.Drawing.Size(100, 20)
        Me.usuario.TabIndex = 17
        '
        'password
        '
        Me.password.Location = New System.Drawing.Point(301, 415)
        Me.password.Name = "password"
        Me.password.Size = New System.Drawing.Size(100, 20)
        Me.password.TabIndex = 18
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(2, 258)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(33, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "mode"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(230, 257)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(24, 13)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "cuit"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(5, 290)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(15, 13)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "id"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(233, 290)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 13)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "uniqueid"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(2, 310)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(34, 13)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "token"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(5, 336)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(26, 13)
        Me.Label6.TabIndex = 24
        Me.Label6.Text = "sign"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(8, 364)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(44, 13)
        Me.Label7.TabIndex = 25
        Me.Label7.Text = "soptype"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(233, 368)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 13)
        Me.Label8.TabIndex = 26
        Me.Label8.Text = "sopnumber"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(8, 388)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(36, 13)
        Me.Label9.TabIndex = 27
        Me.Label9.Text = "server"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(233, 395)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(30, 13)
        Me.Label10.TabIndex = 28
        Me.Label10.Text = "base"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(6, 421)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(27, 13)
        Me.Label11.TabIndex = 29
        Me.Label11.Text = "user"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(233, 422)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(52, 13)
        Me.Label12.TabIndex = 30
        Me.Label12.Text = "password"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(590, 527)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.password)
        Me.Controls.Add(Me.usuario)
        Me.Controls.Add(Me.base)
        Me.Controls.Add(Me.server)
        Me.Controls.Add(Me.sopnumber)
        Me.Controls.Add(Me.soptype)
        Me.Controls.Add(Me.ssign)
        Me.Controls.Add(Me.stoken)
        Me.Controls.Add(Me.sUniqueId)
        Me.Controls.Add(Me.sid)
        Me.Controls.Add(Me.scuit)
        Me.Controls.Add(Me.prodMode)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents prodMode As System.Windows.Forms.TextBox
    Friend WithEvents scuit As System.Windows.Forms.TextBox
    Friend WithEvents sid As System.Windows.Forms.TextBox
    Friend WithEvents sUniqueId As System.Windows.Forms.TextBox
    Friend WithEvents stoken As System.Windows.Forms.TextBox
    Friend WithEvents ssign As System.Windows.Forms.TextBox
    Friend WithEvents soptype As System.Windows.Forms.TextBox
    Friend WithEvents sopnumber As System.Windows.Forms.TextBox
    Friend WithEvents server As System.Windows.Forms.TextBox
    Friend WithEvents base As System.Windows.Forms.TextBox
    Friend WithEvents usuario As System.Windows.Forms.TextBox
    Friend WithEvents password As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label

End Class
